package com.example.demo.service;

import com.example.demo.entity.OpenPosition;

import java.util.List;

public interface OpenPositionsService {

    List<OpenPosition> getOpenPositionsList();
}
