package com.example.demo.service;

import com.example.demo.entity.Award;

import java.util.List;

public interface AwardsService {

    List<Award> getAwardsList();

}
