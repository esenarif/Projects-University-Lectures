package com.example.demo.service;

import com.example.demo.entity.Partner;

import java.util.List;

public interface PartnersService {

    List<Partner> getPartnersList();
}
