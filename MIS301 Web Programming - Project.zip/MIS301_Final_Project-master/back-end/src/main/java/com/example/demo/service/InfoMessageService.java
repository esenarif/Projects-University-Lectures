package com.example.demo.service;

import com.example.demo.entity.InfoMessage;

public interface InfoMessageService {

    InfoMessage postInfo(InfoMessage infoMessage);
}
