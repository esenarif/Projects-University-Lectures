# MYSOFTWARE OFFICIAL WEBSITE


Frontend: vue

Backend: spring-boot(rest api)

DB: MySQL

```
Arif Esen -> HTML&CSS

Hamza Yavuz -> HTML&CSS

Ihsan Tarik Akkoyunlu -> Java&Vue
```
# **SPRING BOOT**

## BACKEND Setup
```
mvn clean install
```
## BACKEND Compile&Run
```
mvn spring-boot:run
```

# **VUE**

## FRONTEND Setup
```
npm install
```

## FRONTEND Compile&Run
```
npm run serve
```

