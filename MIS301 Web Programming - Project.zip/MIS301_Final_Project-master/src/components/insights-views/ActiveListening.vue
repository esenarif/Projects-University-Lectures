<template>
  <div>

    <div class="container my-5">
      <img src="@/assets/insights-com-images/Active-Listening.jpg" alt="">
      <h2 class="title my-4">Active Listening</h2>

      <div class="description">
        <p>
          Active Listening has become a key part of social media management, giving birth to the ability of tracking, measuring performance and predicting the environment. Identifying emerging trends and opportunities help shape the brand’s social media strategy accordingly. Our social media specialists are experts at utilizing the very best tools for active listening, defining opportunities/threats and raising flags before an unwanted situation emerges.
        </p>

      </div>

    </div>

  </div>
</template>

<script>
export default {
  name: "ActiveListening"
}
</script>

<style scoped>
.description{
  font-size: 25px;
}

.title{
  font-size: 40px;
  color: #55ACEE;
}
</style>