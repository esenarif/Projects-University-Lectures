<template>
  <div>

    <div class="container my-5">
      <img src="@/assets/insights-com-images/Social-Data-Insights.jpg" alt="">
      <h2 class="title my-4">Social Data Insights</h2>

      <div class="description">
        <p>
          To get a well-structured and to-the-point information regarding brand’s social media activity, MySostware collaborates with the best global social media platforms to provide our clients with concise and cohesive reports.
        </p>
        <p>
          Alongside active listening, with data insights we provide performance tracking, detailed intents and outreach, conduct competitive analysis where we can learn and predict competitors’ behaviour as well as identify and reach key influencers to boost visibility.
        </p>

      </div>

    </div>

  </div>
</template>

<script>
export default {
  name: "SocialDataInsights"
}
</script>

<style scoped>
.description{
  font-size: 25px;
}

.title{
  font-size: 40px;
  color: #55ACEE;
}
</style>