<template>
  <div>

    <div class="container my-5">
      <img src="@/assets/insights-com-images/Online-Landscape-Analysis.jpg" alt="">
      <h2 class="title my-4">Online Landscape Analysis</h2>

      <div class="description">
        <p>
          Through our experience conducting various research methods involving a variety of sectors, we have concluded that an online landscape analysis not only provides detailed information about the visibility of our partners’ company but also competitors’ or other online initiatives’ direct/indirect impact on them. Using tracking and insight tools we scout online platforms, social media data piles and emerge factual data. Using these data, we can see the strategies used, market metrics formed and points in customer journey that need fortification. Once visible, these concepts become ropes which are attached to a puppet named market dynamics. When we become capable of controlling these dynamics, outcomes show a multitude of opportunities, on line partnering opportunities, optimizing existing partnership, structural improvements, operational adjustments and even re-positioning.
        </p>

      </div>

    </div>

  </div>
</template>

<script>
export default {
  name: "OnlineLandscapeAnalysis"
}
</script>

<style scoped>

.description{
  font-size: 25px;
}

.title{
  font-size: 40px;
  color: #55ACEE;
}
</style>