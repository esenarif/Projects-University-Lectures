<template>
  <div>

    <div class="container my-5">
      <img src="@/assets/martech-com-images/content management.jpg" alt="">
      <h2 class="title my-4">Content Management Systems</h2>

      <div class="description">
        <p>
          Within the last decade of digital transformation, particular digital marketing technologies increased their efficiency to a level which they have become mandatory for potent marketing. Content management systems (CMS) enable web content editors and marketers to have full authority over various aspects of their website such as social integration, blog posts, advanced personalisation, e-commerce, automated marketing circles and much more. After implementing many projects with selecting and establishing management systems; such as CMS, enterprise content management (ECM) and web content management (WCM), we have gained an in-depth understanding of metrics that determine the success of digital marketing. These metrics varies from market to market. To understand them truly, they need hands-on experiments based on theoretical assumptions. However, once understood they give you a step-by-step roadmap which leads to project goals while uncovering many other aspects that help us engage deeper with the customers along the way.
        </p>

      </div>

    </div>

  </div>
</template>

<script>
export default {
  name: "ContentManagementSystem"
}
</script>

<style scoped>
.description{
  font-size: 25px;
}

.title{
  font-size: 40px;
  color: #55ACEE;
}
</style>