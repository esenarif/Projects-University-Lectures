<template>
  <div>

    <div class="container my-5">
      <img src="@/assets/martech-com-images/Omni-Channel Marketing.jpg" alt="">
      <h2 class="title my-4">Multi-Channel Marketing</h2>

      <div class="description">
        <p>
          Consumers are engaging with companies through various channels; virtually or physically, directly or indirectly. Each customer journey for each channel must be monitored and improved constantly. Through this monitoring, points that cause customer loss should be identified and reinforced. Customer journey must be consistent and not situational, it must be complementary, cohesive, measurable and most importantly open to conscious guidance. At mySoftware, we take the role of the customer, analyst and service provider as we go through multi-channel marketing cycles. From lead management to email marketing, from customer base ads to mobile marketing; we install and manage a predictive, actionable marketing platform which allows us to anticipate customer behaviours based on audience profiling and case stories. With a behavioural system in progress, we then help brand’s customers to move from one channel to another, each step progressing in a sustainable manner towards a pre-determined resolution which encompasses CTAs (call-to-action) and KPIs.
        </p>

      </div>

    </div>

  </div>
</template>

<script>
export default {
  name: "OmniChannelMarketinh"
}
</script>

<style scoped>
.description{
  font-size: 25px;
}

.title{
  font-size: 40px;
  color: #55ACEE;
}
</style>