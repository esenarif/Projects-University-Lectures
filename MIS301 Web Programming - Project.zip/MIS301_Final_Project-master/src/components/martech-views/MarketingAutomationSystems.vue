<template>
  <div>

    <div class="container my-5">
      <img src="@/assets/martech-com-images/Marketing-Automation.jpg" alt="">
      <h2 class="title my-4">Marketing Automation Systems</h2>

      <div class="description">
        <p>
          Successful marketing automation differs in many ways from traditional marketing automation systems that we consider to be completely limited approaches. A reformed and up-to-date marketing automation approach should take the evolving and morphing needs of your leads’ into consideration, able to swiftly response to change and deviation from a set user story.
        </p>

        <p>
          Combined with multi-channel marketing, automated efforts center around the prospects. Obtaining customer input that includes traits, behavioural aspects, wants/needs and corresponding this valuable information with CTAs and KPIs set within our approach allows our marketing team to fully understand your customer journey. A successful marketing automation methodology is not simply a data collection process, it is obliged to use various channels to send the tailored marketing message. Our team is then set on to maximize the success of your campaign, relying less and less on traditional approaches and more on the various channels that are able to influence a buyer’s motives.
        </p>

      </div>

    </div>

  </div>
</template>

<script>
export default {
  name: "MarketingAutomationSystems"
}
</script>

<style scoped>

.description{
  font-size: 25px;
}

.title{
  font-size: 40px;
  color: #55ACEE;
}

</style>