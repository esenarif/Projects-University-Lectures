<template>
  <div>

    <div class="container my-5">
      <img src="@/assets/martech-com-images/seo-sam management.jpg" alt="">
      <h2 class="title my-4">SEO - SEM Management </h2>

      <div class="description">
        <p>
          All search engines, especially Google, expect their websites to be SEO compliant. All the web sites we design as mySoftware are our SEO priorities.
        </p>

      </div>

    </div>

  </div>
</template>

<script>
export default {
  name: "SeoSemManagement"
}
</script>

<style scoped>
.description{
  font-size: 25px;
}

.title{
  font-size: 40px;
  color: #55ACEE;
}

</style>