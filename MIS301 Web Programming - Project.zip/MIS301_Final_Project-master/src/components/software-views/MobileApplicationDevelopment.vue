<template>
<div>
  <div class="container my-5">
    <img src="@/assets/software-com-images/Mobile-Application-Development-1-408x245.jpg" alt="">
    <h2 class="title my-4">Mobile Application Development  </h2>

    <div class="description">
      <p>
        At MySoftware, rather than initiating developing processes right away we analyse the problems that our partners faced and required software solutions. We take process insights from our partners and merge it with our technological know-how. From this collaboration a new solution is emerged with greater impact and cost effectiveness. Along with custom software development, we provide software maintenance and on-demand customizations.
      </p>

      <p>Our team of specialists, each have years of software development experience, will deliver top quality solutions on the following technologies;</p>
      <ul>
        <li>Backend and Desktop: .NET, Java, PHP, Node.js, C#</li>
        <li>Mobile: iOS, Android, Xamarin</li>
        <li>Frontend: HTML5, CSS3, JS</li>
        <li>Databases: Microsoft SQL Server, MySQL, Oracle, SQL Azure, PostgreSQL, MongoDB</li>
      </ul>

    </div>

  </div>
</div>
</template>

<script>
export default {
  name: "MobileApplicationDevelopment"
}
</script>

<style scoped>
.description{
  font-size: 25px;
}

.title{
  font-size: 40px;
  color: #55ACEE;
}
</style>