<template>
  <div>

    <div class="container my-5">
      <img src="@/assets/software-com-images/Website-Design-And-Development-408x245.jpg" alt="">
      <h2 class="title my-4">Website Design And Development </h2>

      <div class="description">
        <p>

        </p>
        <p>
          MySoftware approaches the concept of portal design and management from a business perspective and begins with thoroughly analysing a company's business practices, competitors, strategies and plans.
        </p>

        <p>
          The portals we design and manage stand as testimonies to the approach of helping our partners to enhance their ROI and brand awareness while getting ahead of their competitors.
        </p>

        <p>
          “While building web portals suited to our partner’s needs, we stay in line with brand’s persona and value proposition. To define the project strategy, we consider the following concepts to provide a general understanding of the process before giving more details.
        </p>

        <ul>
          <li>Process Mapping helps us map the inner procedures of a company which will have direct or indirect effects on the functionality and the looks of the portal.</li>
          <li>Segmentation is used to classify our target audience and personalise the portal accordingly.</li>
          <li>Business Requirement Plan lists out all the functions, modules and pages of the desired portal for the final approval of the partner.</li>
          <li>Wireframing presents our partners with the outlines of how the portal’s workflows will materialize vis-à-vis the design elements on their pages.</li>
          <li>Look and Feel phase enables us to get an insight on the kind of image our partners want their site to portray.</li>
          <li>
            Design takes input from all the above and builds a skeleton of the portal in three different layers:
            <ul style="list-style-type:circle;">
              <li>Graphic Design</li>
              <li>Database Design</li>
              <li>Class Design</li>
            </ul>
          </li>
          <li>Coding starts after all the phases mentioned above are discussed and decided with the partner.</li>

        </ul>




      </div>



    </div>

  </div>
</template>

<script>
export default {
  name: "WebsiteDesignAndDevelopment"
}
</script>

<style scoped>

.description{
  font-size: 25px;
}

.title{
  font-size: 40px;
  color: #55ACEE;
}

</style>