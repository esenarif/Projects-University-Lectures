<template>
  <div>

    <div class="container my-5">
      <img src="@/assets/social-com-images/Social-Media-Governance.jpg" alt="">
      <h2 class="title my-4">Social Media Governance & Security</h2>

      <div class="description">
        <p>
          With its rising influence, social media has also become a target for cyber-attacks. According to Cisco’s annual report 2016, most web-based attacks happen on social media. Every company faces a set of risks on social media platforms. These risks, if not counterbalanced, may damage the brand irrevocably. MySoftware collaborates with trusted social media security platforms to ensure efforts spent for building the brand are not vanished in seconds. With these collaborators we analyse dynamic social media data, protect our partners against security and business threats. We have proven track record regarding handling crisis situations, eliminating fraud/scams and impersonating accounts along with protecting corporate accounts from compromise.
        </p>

      </div>

    </div>

  </div>
</template>

<script>
export default {
  name: "SocialMediaGovernanceAndSecurity"
}
</script>

<style scoped>
.description{
  font-size: 25px;
}

.title{
  font-size: 40px;
  color: #55ACEE;
}
</style>