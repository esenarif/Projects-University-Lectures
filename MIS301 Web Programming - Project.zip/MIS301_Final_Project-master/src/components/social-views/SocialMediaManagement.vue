<template>
  <div>

    <div class="container my-5">
      <img src="@/assets/social-com-images/Social-Media-Management.jpg" alt="">
      <h2 class="title my-4">Social Media Management</h2>

      <div class="description">
        <p>
          We think of social media as a portal that allows us to make our partner’s brand equity stronger than ever. By combining creative thinking with profiling target audience, we engender social media content that increases brand engagement while targeting project goals.
        </p>

        <p>
          Even though social media management is a branch that requires intense creativity which can not be measured, its success is easily can. We use analytic tools to track thresholds that were identified to achieve project goals. With every content, project and campaign we analyse our target audience deeper to address sharper and to expand faster.
        </p>

      </div>

    </div>

  </div>
</template>

<script>
export default {
  name: "SocialMediaManagement"
}
</script>

<style scoped>
.description{
  font-size: 25px;
}

.title{
  font-size: 40px;
  color: #55ACEE;
}

</style>