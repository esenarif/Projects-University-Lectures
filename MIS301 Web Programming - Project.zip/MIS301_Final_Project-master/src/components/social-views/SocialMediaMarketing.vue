<template>
  <div>

    <div class="container my-5">
      <img src="@/assets/social-com-images/Social-Media-Marketing.jpg" alt="">
      <h2 class="title my-4">Social Media Marketing</h2>

      <div class="description">
        <p>
          MySoftware has variety of social media specialists who want to help build our partners’ social media strategies. To maximize efficiency, our team creates a digital persona that represents the brand. Then this persona is brought to life by identifying what to say, when to say and how often to say it. Which stands for message of the content, timing of that particular content and frequency of that message.
        </p>

        <p>
          We only use tools that gives us maximum control over social media platforms. With only these tools we will be certain that contents generated, social ads that are delivered and marketing investments expended provide the best they can. These tools help us create a marketing strategy that uses dynamic data to stay up to date,  create an  automated marketing cycle to reach all our target audience but being personal while doing so.
        </p>

      </div>

    </div>

  </div>
</template>

<script>
export default {
  name: "SocialMediaMarketing"
}
</script>

<style scoped>
.description{
  font-size: 25px;
}

.title{
  font-size: 40px;
  color: #55ACEE;
}
</style>